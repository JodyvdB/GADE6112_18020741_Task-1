﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    public partial class frmRTSMain : Form
    {
        // Creating a GameEngine object.
        GameEngine engine;
        int count = 0;

        public frmRTSMain()
        {
            InitializeComponent();
        }

        // When the form is loaded, the engine object is instantiated.
        private void frmRTSMain_Load(object sender, EventArgs e)
        {
            engine = new GameEngine(this, this.grpBxInfo);
        }

        // Whenever a tick happens in the timer, the timestamp is updated and the entire board of units is updated and moved.
        private void tmrGameTime_Tick(object sender, EventArgs e)
        {
            engine.updateMap();
            engine.updateDisplay();
            lblTimeStamp.Text = (++count).ToString();
        }

        // Method that adds a string to the listbox.
        public void displayInfo(string msg)
        {
            lstBxUnitInfo.Items.Add(msg);
        }

        // When the exit button is clicked, the form is closed and the program ends.
        private void btnExit_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = false;
            Environment.Exit(0);
        }

        // When the play button is clicked, the timer starts/continues and the simulation begins.
        private void btnPlay_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = true;
            engine.updateMap();
            engine.updateDisplay();
            lblTimeStamp.Text = (++count).ToString();
        }

        // When the pause button is clicked, the timer is disabled (keeping its value of time) until play is clicked again.
        private void btnPause_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = false;
        }   
    }
}
