﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    class Map
    {
        // MY ATTEMPT: 
        //
        //private char[,] mapPos = new char[20, 20];
        //private int uType, xPos, yPos, numUnits;
        //private Random ran = new Random();

        //public Map(int numUnits)
        //{
        //    this.numUnits = numUnits;
        //}


        // SECOND ATTEMPT:
        // New Unit array to spawn 10 different units later on.
        public Unit[] units = new Unit[10];

        // constructor
        public Map()
        {
            // Using the Random class, we can randomize different characteristics of the different units.
            Random r = new Random();
            // Running a for loop for as many units there are in the array.
            for (int loop = 0; loop < units.Length; loop++)
            {
                int newX = r.Next(0, 20);
                int newY = r.Next(0, 20);

                // '%' or 'mod' is used as a way to calculate the remainder of a division calculation.
                int team = loop % 2;

                int tempAttack = 0;

                // Here we are randomizing the units' potential attack damage values.
                switch (r.Next(0, 4))
                {
                    case 0: tempAttack = 40;  break;
                    case 1: tempAttack = 50;  break;
                    case 2: tempAttack = 60;  break;
                    case 3: tempAttack = 90;  break;
                }

                // Depending which team value was randomized, a unit will be created using the Melee or Ranged units classes/objects in the team that was randomized.
                switch (r.Next(0, 2))
                {
                    case 0: units[loop] = new MeleeUnit(newX, newY, 100, 2, tempAttack, 30, team, loop.ToString()); break;
                    case 1: units[loop] = new RangedUnit(newX, newY, 100, 1, tempAttack, 90, team, loop.ToString()); break;
                }
            }
        }
    }
}
